import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    'Variáveis de ambiente do Supabase ausentes. Confira se VITE_SUPABASE_URL e ' +
    'VITE_SUPABASE_ANON_KEY estão definidas no arquivo .env (local) ou nas ' +
    'Environment Variables do projeto na Vercel.'
  );
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

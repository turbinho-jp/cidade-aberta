// Controle de acesso simples para o painel da prefeitura.
//
// Aceita VITE_ADMIN_PASSWORD (variável de ambiente) ou o código fixo BESSA2026
// como fallback — útil em demos e ambientes sem .env configurado.
// A sessão é mantida no sessionStorage (some ao fechar a aba).
//
// IMPORTANTE: isso protege a INTERFACE, não o banco de dados. Para produção,
// evoluir para Supabase Auth com usuários reais da prefeitura.

import { ADMIN_ACCESS_CODE } from '../data/constants';

const SESSION_KEY = 'prefeitura_admin_unlocked';
const SESSION_NAME_KEY = 'prefeitura_admin_name';
const DEFAULT_ADMIN_NAME = 'Equipe da Prefeitura';

export function isAdminUnlocked(): boolean {
  try {
    return sessionStorage.getItem(SESSION_KEY) === 'true';
  } catch {
    return false;
  }
}

export function getAdminName(): string {
  try {
    return sessionStorage.getItem(SESSION_NAME_KEY) || DEFAULT_ADMIN_NAME;
  } catch {
    return DEFAULT_ADMIN_NAME;
  }
}

export function unlockAdmin(password: string): { success: boolean; message: string } {
  // Aceita a variável de ambiente OU o código fixo como fallback.
  const correctPassword = import.meta.env.VITE_ADMIN_PASSWORD || ADMIN_ACCESS_CODE;

  if (password === correctPassword) {
    try {
      sessionStorage.setItem(SESSION_KEY, 'true');
      sessionStorage.setItem(SESSION_NAME_KEY, DEFAULT_ADMIN_NAME);
    } catch {
      // sessionStorage indisponível (modo privado restrito, etc.) — segue sem persistir
    }
    return { success: true, message: '' };
  }

  return { success: false, message: 'Código de acesso incorreto.' };
}

export function lockAdmin(): void {
  try {
    sessionStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_NAME_KEY);
  } catch {
    // ignore
  }
}

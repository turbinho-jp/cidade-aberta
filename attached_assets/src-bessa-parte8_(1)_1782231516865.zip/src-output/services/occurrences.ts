import { supabase } from '../lib/supabase';
import { Category, NewOccurrence, Occurrence, OccurrenceStatus } from '../types';

/**
 * Busca todas as categorias cadastradas, ordenadas por nome.
 */
export async function fetchCategories(): Promise<Category[]> {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .order('name', { ascending: true });

  if (error) throw error;
  return data ?? [];
}

/**
 * Busca todas as ocorrências, já trazendo a categoria relacionada (join),
 * ordenadas das mais recentes para as mais antigas.
 */
export async function fetchOccurrences(): Promise<Occurrence[]> {
  const { data, error } = await supabase
    .from('occurrences')
    .select('*, category:categories(*)')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return (data ?? []) as Occurrence[];
}

/**
 * Insere uma nova ocorrência reportada pela população.
 * Retorna o registro já com a categoria relacionada (join), pronto para
 * ser exibido no mapa sem precisar recarregar tudo do banco.
 */
export async function createOccurrence(payload: NewOccurrence): Promise<Occurrence> {
  const { data, error } = await supabase
    .from('occurrences')
    .insert({
      title: payload.title,
      description: payload.description,
      category_id: payload.category_id,
      latitude: payload.latitude,
      longitude: payload.longitude,
      address: payload.address ?? null,
      street_address: payload.street_address,
      reference_point: payload.reference_point,
      severity: payload.severity,
      user_name: payload.user_name,
      user_email: payload.user_email ?? null,
      user_phone: payload.user_phone ?? null,
      image_url: payload.image_url ?? null,
      status: 'pending' as OccurrenceStatus,
    })
    .select('*, category:categories(*)')
    .single();

  if (error) throw error;
  return data as Occurrence;
}

/**
 * Atualiza o status de uma ocorrência (usado pelo painel da prefeitura)
 * e opcionalmente registra quem resolveu / uma nota administrativa.
 * Também grava uma entrada em occurrence_updates para manter o histórico.
 */
export async function updateOccurrenceStatus(
  occurrenceId: string,
  newStatus: OccurrenceStatus,
  adminName: string,
  adminNotes?: string,
  responsibleOrgan?: string
): Promise<Occurrence> {
  const isResolved = newStatus === 'resolved';

  const { data, error } = await supabase
    .from('occurrences')
    .update({
      status: newStatus,
      resolved_at: isResolved ? new Date().toISOString() : null,
      resolved_by: isResolved ? adminName : null,
      admin_notes: adminNotes ?? null,
      responsible_organ: responsibleOrgan ?? null,
    })
    .eq('id', occurrenceId)
    .select('*, category:categories(*)')
    .single();

  if (error) throw error;

  // Registra a mudança no histórico de atualizações (não bloqueia o fluxo principal se falhar)
  await supabase.from('occurrence_updates').insert({
    occurrence_id: occurrenceId,
    author_name: adminName,
    author_type: 'admin',
    content: adminNotes ? adminNotes : `Status alterado para "${newStatus}"`,
    status_change: newStatus,
  });

  return data as Occurrence;
}

// Geocodificação reversa gratuita usando o Nominatim (OpenStreetMap).
// Dada uma coordenada, retorna o endereço legível mais próximo — usado para
// pré-preencher o campo "Rua e número" quando o cidadão clica no mapa.
//
// Política de uso do Nominatim (https://operations.osmfoundation.org/policies/nominatim/):
// - Máximo 1 requisição por segundo
// - É obrigatório enviar um identificador da aplicação (não usamos API key,
//   então identificamos via um parâmetro "email" genérico do projeto não é
//   necessário — o header/param exigido é apenas um User-Agent ou Referer
//   válido, que o navegador já envia automaticamente).

export interface ForwardGeocodeResult {
  /** Latitude da coordenada encontrada. */
  lat: number;
  /** Longitude da coordenada encontrada. */
  lng: number;
  /** Endereço formatado retornado pelo Nominatim. */
  displayName: string;
}

/**
 * Busca as coordenadas de um endereço digitado via Nominatim (geocodificação direta).
 * Sempre faz a busca com viés para João Pessoa / Bessa para priorizar resultados locais.
 * Retorna `null` se não encontrar nada ou se a requisição falhar.
 */
export async function forwardGeocode(address: string): Promise<ForwardGeocodeResult | null> {
  if (!address.trim() || address.trim().length < 5) return null;

  try {
    // viewbox e bounded=1 priorizam João Pessoa; se não achar, o Nominatim
    // expande a busca automaticamente (bounded=0 seria global, mas preferimos
    // o resultado local quando ambíguo).
    const query = encodeURIComponent(address.trim() + ', João Pessoa, Paraíba, Brasil');
    const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&q=${query}&limit=1&addressdetails=1&accept-language=pt-BR`;

    const response = await fetch(url, {
      headers: { Accept: 'application/json' },
    });

    if (!response.ok) return null;

    const data = await response.json();
    if (!Array.isArray(data) || data.length === 0) return null;

    const result = data[0];
    return {
      lat: parseFloat(result.lat),
      lng: parseFloat(result.lon),
      displayName: result.display_name || address,
    };
  } catch (err) {
    console.error('Erro na geocodificação direta (Nominatim):', err);
    return null;
  }
}

export interface ReverseGeocodeResult {
  /** Endereço pronto pra preencher o campo "Rua e número" (ex: "Av. Min. José Américo de Almeida, 482"). */
  formattedAddress: string;
  /** Resposta crua do Nominatim, caso seja útil no futuro (bairro, cidade, etc). */
  raw: Record<string, unknown>;
}

/**
 * Busca o endereço aproximado de uma coordenada via Nominatim.
 * Retorna `null` se não encontrar nada ou se a requisição falhar — o
 * chamador deve tratar isso preenchendo o campo manualmente, sem travar
 * o fluxo do usuário.
 */
export async function reverseGeocode(lat: number, lng: number): Promise<ReverseGeocodeResult | null> {
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1&accept-language=pt-BR`;

    const response = await fetch(url, {
      headers: {
        // O Nominatim exige um identificador da aplicação. Como rodamos no
        // navegador do usuário (sem backend próprio), usamos o Referer
        // padrão do fetch — é o que a política deles aceita para uso leve,
        // não-comercial, como este.
        Accept: 'application/json',
      },
    });

    if (!response.ok) return null;

    const data = await response.json();
    if (!data || data.error) return null;

    const addr = data.address || {};
    const street = addr.road || addr.pedestrian || addr.footway || '';
    const houseNumber = addr.house_number || '';

    // Monta "Rua Tal, 123" quando tem número, ou só "Rua Tal" quando não tem
    // (comum em vias sem numeração, como loteamentos novos).
    const formattedAddress = street
      ? (houseNumber ? `${street}, ${houseNumber}` : street)
      : (data.display_name?.split(',').slice(0, 2).join(',').trim() || '');

    if (!formattedAddress) return null;

    return { formattedAddress, raw: data };
  } catch (err) {
    console.error('Erro na geocodificação reversa (Nominatim):', err);
    return null;
  }
}

import {
  Trees,
  Building,
  Shield,
  Heart,
  Bus,
  GraduationCap,
  MoreHorizontal,
  MapPin,
  LucideIcon,
} from 'lucide-react';

// Mapeia o nome do ícone salvo na coluna `icon` da tabela `categories`
// (ver supabase/migrations/..._001_initial_schema.sql) para o componente
// do lucide-react correspondente.
const iconMap: Record<string, LucideIcon> = {
  Trees,
  Building,
  Shield,
  Heart,
  Bus,
  GraduationCap,
  MoreHorizontal,
};

export function getCategoryIcon(iconName: string): LucideIcon {
  return iconMap[iconName] ?? MapPin;
}

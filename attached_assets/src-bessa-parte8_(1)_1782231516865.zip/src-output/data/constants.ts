import { Severity, OccurrenceStatus } from '../types';

// Centro do bairro do Bessa (João Pessoa/PB) e zoom inicial do mapa.
export const BESSA_CENTER = { lat: -7.0963, lng: -34.8286 };
export const BESSA_DEFAULT_ZOOM = 15;

// Zoom máximo usado quando o mapa foca automaticamente em um ponto (ao
// selecionar uma ocorrência ou ao entrar no modo "Reportar"). Acima disso,
// a imagem de satélite fica tão próxima que o pino parece cair dentro do
// lote errado. O usuário ainda pode dar zoom manual além disso se quiser.
export const MAX_AUTO_FOCUS_ZOOM = 17;

export const statusLabels: Record<OccurrenceStatus, string> = {
  pending: 'Pendente',
  in_progress: 'Em Andamento',
  resolved: 'Resolvido',
  rejected: 'Rejeitado',
};

// Cor do marcador no mapa por status — é essa cor que muda quando a
// prefeitura atualiza o status de uma ocorrência.
export const statusColors: Record<OccurrenceStatus, { marker: string; bg: string; text: string; border: string }> = {
  pending: { marker: '#ef4444', bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' },
  in_progress: { marker: '#f59e0b', bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200' },
  resolved: { marker: '#22c55e', bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200' },
  rejected: { marker: '#6b7280', bg: 'bg-slate-100', text: 'text-slate-600', border: 'border-slate-300' },
};

export const severityLabels: Record<Severity, string> = {
  low: 'Baixa',
  medium: 'Média',
  high: 'Alta',
  critical: 'Crítica',
};

// Código de acesso fixo para o painel da prefeitura (fallback quando
// VITE_ADMIN_PASSWORD não está configurado no .env).
export const ADMIN_ACCESS_CODE = 'BESSA2026';

// Órgãos da prefeitura que podem ser atribuídos como responsáveis.
export const RESPONSIBLE_ORGANS = [
  { value: 'SEINFRA', label: 'SEINFRA — Secretaria de Infraestrutura' },
  { value: 'EMLUR', label: 'EMLUR — Limpeza Urbana' },
  { value: 'SEDURB', label: 'SEDURB — Desenvolvimento Urbano' },
  { value: 'SEMAM', label: 'SEMAM — Meio Ambiente' },
  { value: 'STTRANS', label: 'STTRANS — Trânsito' },
  { value: 'Outros', label: 'Outros' },
] as const;

export type ResponsibleOrgan = typeof RESPONSIBLE_ORGANS[number]['value'];

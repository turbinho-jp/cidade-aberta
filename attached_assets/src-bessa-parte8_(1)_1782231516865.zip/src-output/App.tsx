import { useState, useEffect, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import MapContainerComponent from './components/MapContainer';
import OccurrenceForm, { OccurrenceFormData } from './components/OccurrenceForm';
import AlertDetail from './components/AlertDetail';
import StatusBar from './components/StatusBar';
import { Occurrence, Category, FilterState, MapCoordinates, OccurrenceStatus } from './types';
import { BESSA_CENTER, BESSA_DEFAULT_ZOOM, MAX_AUTO_FOCUS_ZOOM } from './data/constants';
import { fetchCategories, fetchOccurrences, createOccurrence, updateOccurrenceStatus } from './services/occurrences';
import { Loader2, AlertTriangle, RefreshCw } from 'lucide-react';

function App() {
  const [occurrences, setOccurrences] = useState<Occurrence[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [selectedOccurrence, setSelectedOccurrence] = useState<Occurrence | null>(null);
  const [isAddingMode, setIsAddingMode] = useState(false);
  const [newOccurrenceCoords, setNewOccurrenceCoords] = useState<MapCoordinates | null>(null);

  const [mapCenter, setMapCenter] = useState<MapCoordinates>(BESSA_CENTER);
  const [mapZoom, setMapZoom] = useState(BESSA_DEFAULT_ZOOM);

  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    statuses: [],
    severities: [],
    dateRange: { start: null, end: null },
    search: '',
    showResolved: false,
  });

  // Ocorrências "Resolvidas" ficam ocultas do mapa e da lista por padrão
  // (poluem a visualização com histórico antigo) — só aparecem se o
  // usuário ativar "Mostrar resolvidas" no menu de Filtros. A StatusBar
  // continua usando `occurrences` (lista completa) para os contadores
  // gerenciais no topo, que devem refletir o total real.
  const visibleOccurrences = filters.showResolved
    ? occurrences
    : occurrences.filter(occ => occ.status !== 'resolved');

  // Carrega categorias e ocorrências reais do Supabase assim que a página abre.
  const loadData = useCallback(async () => {
    setIsLoading(true);
    setLoadError(null);
    try {
      const [categoriesData, occurrencesData] = await Promise.all([
        fetchCategories(),
        fetchOccurrences(),
      ]);
      setCategories(categoriesData);
      setOccurrences(occurrencesData);
    } catch (err) {
      console.error('Erro ao carregar dados do Supabase:', err);
      setLoadError(
        'Não foi possível carregar as ocorrências. Verifique sua conexão com a internet e tente novamente.'
      );
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Foca o mapa numa ocorrência (clique na sidebar ou no marcador), sem
  // nunca ultrapassar MAX_AUTO_FOCUS_ZOOM — evita que o mapa "afunde" demais
  // na imagem de satélite e o pino pareça cair em outro lote.
  const handleSelectOccurrence = (occurrence: Occurrence | null) => {
    setSelectedOccurrence(occurrence);
    if (occurrence) {
      setMapCenter({ lat: occurrence.latitude, lng: occurrence.longitude });
      setMapZoom(prev => Math.min(prev, MAX_AUTO_FOCUS_ZOOM));
    }
  };

  const handleAddClick = () => {
    setIsAddingMode(true);
    setSelectedOccurrence(null);
    // Também respeita o limite ao entrar no modo "Reportar", para o
    // usuário não precisar clicar num zoom já muito apertado.
    setMapZoom(prev => Math.min(prev, MAX_AUTO_FOCUS_ZOOM));
  };

  const handleMapAddOccurrence = (coordinates: MapCoordinates) => {
    setNewOccurrenceCoords(coordinates);
    setIsAddingMode(false);
  };

  const handleCancelAdd = () => {
    setIsAddingMode(false);
    setNewOccurrenceCoords(null);
  };

  // Salva a ocorrência reportada pelo cidadão no Supabase e atualiza a lista local
  // sem precisar recarregar tudo do banco.
  const handleSubmitOccurrence = async (data: OccurrenceFormData) => {
    const created = await createOccurrence({
      title: data.title,
      description: data.description,
      category_id: data.category_id,
      latitude: data.latitude,
      longitude: data.longitude,
      street_address: data.street_address,
      reference_point: data.reference_point,
      severity: data.severity,
      user_name: data.user_name,
      user_email: data.user_email || undefined,
      user_phone: data.user_phone || undefined,
      image_url: data.image_url || undefined,
    });

    setOccurrences(prev => [created, ...prev]);
    setNewOccurrenceCoords(null);
    handleSelectOccurrence(created);
  };

  // Usado pelo painel de gestão da prefeitura (AlertDetail) para mudar o status
  // de uma ocorrência. A cor do marcador no mapa muda automaticamente porque
  // depende de occ.status, que vem do estado atualizado aqui.
  const handleUpdateStatus = async (occurrenceId: string, newStatus: OccurrenceStatus, adminNotes?: string, responsibleOrgan?: string) => {
    const updated = await updateOccurrenceStatus(occurrenceId, newStatus, 'Equipe da Prefeitura', adminNotes, responsibleOrgan);
    setOccurrences(prev => prev.map(occ => (occ.id === occurrenceId ? updated : occ)));
    setSelectedOccurrence(updated);
  };

  // ─── Loading state ──────────────────────────────────────────────
  if (isLoading) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <Loader2 size={32} className="animate-spin text-emerald-600 mx-auto mb-3" />
          <p className="text-slate-500 text-sm font-medium">Carregando ocorrências...</p>
        </div>
      </div>
    );
  }

  // ─── Error state (ex: .env não configurado, sem internet) ───────
  if (loadError) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-slate-50 px-4">
        <div className="text-center max-w-md">
          <div className="w-14 h-14 mx-auto mb-4 bg-red-50 rounded-full flex items-center justify-center border border-red-200">
            <AlertTriangle size={24} className="text-red-500" />
          </div>
          <h2 className="text-lg font-semibold text-slate-800 mb-1">Não foi possível carregar os dados</h2>
          <p className="text-sm text-slate-500 mb-5">{loadError}</p>
          <button
            onClick={loadData}
            className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium transition-colors"
          >
            <RefreshCw size={14} />
            Tentar novamente
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-50 overflow-hidden">
      <StatusBar occurrences={occurrences} />

      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          occurrences={visibleOccurrences}
          allOccurrences={occurrences}
          categories={categories}
          filters={filters}
          onFiltersChange={setFilters}
          selectedOccurrence={selectedOccurrence}
          onSelectOccurrence={handleSelectOccurrence}
          onAddClick={handleAddClick}
        />

        <div className="flex-1 relative">
          <MapContainerComponent
            occurrences={visibleOccurrences}
            categories={categories}
            selectedOccurrence={selectedOccurrence}
            onSelectOccurrence={handleSelectOccurrence}
            onAddOccurrence={handleMapAddOccurrence}
            isAddingMode={isAddingMode}
            onCancelAdd={handleCancelAdd}
            center={mapCenter}
            zoom={mapZoom}
            onCenterChange={setMapCenter}
            onZoomChange={setMapZoom}
          />
        </div>

        {selectedOccurrence && (
          <AlertDetail
            occurrence={selectedOccurrence}
            onClose={() => setSelectedOccurrence(null)}
            onUpdateStatus={handleUpdateStatus}
          />
        )}

        {newOccurrenceCoords && (
          <OccurrenceForm
            coordinates={newOccurrenceCoords}
            categories={categories}
            onClose={() => setNewOccurrenceCoords(null)}
            onSubmit={handleSubmitOccurrence}
            onCoordinatesChange={(coords) => {
              setNewOccurrenceCoords(coords);
              setMapCenter(coords);
              setMapZoom(17);
            }}
          />
        )}
      </div>
    </div>
  );
}

export default App;

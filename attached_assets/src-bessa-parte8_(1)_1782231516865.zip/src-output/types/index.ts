export type OccurrenceStatus = 'pending' | 'in_progress' | 'resolved' | 'rejected';
export type Severity = 'low' | 'medium' | 'high' | 'critical';
export type AuthorType = 'community' | 'admin';

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  color: string;
  description: string | null;
  created_at: string;
}

export interface OccurrenceUpdate {
  id: string;
  occurrence_id: string;
  author_name: string;
  author_type: AuthorType;
  content: string;
  status_change: string | null;
  created_at: string;
}

export interface Occurrence {
  id: string;
  title: string;
  description: string;
  category_id: string;
  latitude: number;
  longitude: number;
  address: string | null;
  street_address: string | null;
  reference_point: string | null;
  status: OccurrenceStatus;
  severity: Severity;
  user_name: string;
  user_email: string | null;
  user_phone: string | null;
  image_url: string | null;
  resolved_at: string | null;
  resolved_by: string | null;
  admin_notes: string | null;
  responsible_organ: string | null;
  created_at: string;
  updated_at: string;
  category?: Category;
  updates?: OccurrenceUpdate[];
}

export interface NewOccurrence {
  title: string;
  description: string;
  category_id: string;
  latitude: number;
  longitude: number;
  address?: string;
  // Obrigatórios no formulário (mesmo sendo opcionais no banco, para não
  // quebrar ocorrências antigas que não tinham esses campos).
  street_address: string;
  reference_point: string;
  severity: Severity;
  user_name: string;
  user_email?: string;
  user_phone?: string;
  image_url?: string;
}

export interface MapBounds {
  north: number;
  south: number;
  east: number;
  west: number;
}

export interface FilterState {
  categories: string[];
  statuses: OccurrenceStatus[];
  severities: Severity[];
  dateRange: {
    start: string | null;
    end: string | null;
  };
  search: string;
  // Por padrão (false), ocorrências com status "resolved" ficam ocultas no
  // mapa e na lista — evita poluir a visualização com histórico antigo.
  // O usuário liga isso manualmente no menu de Filtros para ver o histórico.
  showResolved: boolean;
}

export interface MapCoordinates {
  lat: number;
  lng: number;
}

import { useEffect, useRef } from 'react';
import { MapContainer as LeafletMap, TileLayer, Marker, Popup, useMapEvents, useMap, LayersControl, LayerGroup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Occurrence, Category, MapCoordinates } from '../types';
import { Navigation, Plus, Minus, Layers } from 'lucide-react';
import { statusColors, statusLabels } from '../data/constants';

interface MapContainerProps {
  occurrences: Occurrence[];
  categories: Category[];
  selectedOccurrence: Occurrence | null;
  onSelectOccurrence: (occurrence: Occurrence | null) => void;
  onAddOccurrence: (coordinates: MapCoordinates) => void;
  isAddingMode: boolean;
  onCancelAdd: () => void;
  center: MapCoordinates;
  zoom: number;
  onCenterChange: (center: MapCoordinates) => void;
  onZoomChange: (zoom: number) => void;
}

function createStatusIcon(color: string, categoryColor: string, isSelected: boolean) {
  const size = isSelected ? 38 : 30;
  return L.divIcon({
    html: `
      <div style="position: relative; width: ${size}px; height: ${size}px;">
        <div style="
          width: ${size}px; height: ${size}px; background-color: ${color};
          border-radius: 50% 50% 50% 0; transform: rotate(-45deg);
          border: 2.5px solid white; box-shadow: 0 2px 8px rgba(0,0,0,0.35);
        "></div>
        <div style="
          position: absolute; top: -2px; right: -2px; width: 10px; height: 10px;
          border-radius: 50%; background-color: ${categoryColor}; border: 2px solid white;
        "></div>
      </div>
    `,
    className: 'bessa-marker-icon',
    iconSize: [size, size],
    iconAnchor: [size / 2, size],
    popupAnchor: [0, -size],
  });
}

function ClickHandler({ isAddingMode, onAddOccurrence }: { isAddingMode: boolean; onAddOccurrence: (c: MapCoordinates) => void }) {
  useMapEvents({
    click(e) {
      if (isAddingMode) onAddOccurrence({ lat: e.latlng.lat, lng: e.latlng.lng });
    },
  });
  return null;
}

function FlyToOnExternalChange({ center, zoom }: { center: MapCoordinates; zoom: number }) {
  const map = useMap();
  const lastExternalCenter = useRef(center);

  useEffect(() => {
    const current = map.getCenter();
    const distanceFromMap = Math.abs(current.lat - center.lat) + Math.abs(current.lng - center.lng);
    const distanceFromLastExternal = Math.abs(lastExternalCenter.current.lat - center.lat) + Math.abs(lastExternalCenter.current.lng - center.lng);
    if (distanceFromMap > 0.0005 && distanceFromLastExternal > 0.0001) {
      map.flyTo([center.lat, center.lng], zoom, { duration: 0.7 });
    }
    lastExternalCenter.current = center;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [center.lat, center.lng, zoom]);

  return null;
}

function ViewportSync({ onCenterChange, onZoomChange }: { onCenterChange: (c: MapCoordinates) => void; onZoomChange: (z: number) => void }) {
  useMapEvents({
    moveend(e) { const c = e.target.getCenter(); onCenterChange({ lat: c.lat, lng: c.lng }); },
    zoomend(e) { onZoomChange(e.target.getZoom()); },
  });
  return null;
}

function ZoomButtons() {
  const map = useMap();
  return (
    <div className="absolute right-4 top-4 flex flex-col gap-1.5 z-[1000]">
      <button
        onClick={() => map.zoomIn()}
        className="w-9 h-9 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-center text-slate-600 hover:text-slate-900 transition-all shadow-lg"
      >
        <Plus size={18} strokeWidth={2.5} />
      </button>
      <button
        onClick={() => map.zoomOut()}
        className="w-9 h-9 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-center text-slate-600 hover:text-slate-900 transition-all shadow-lg"
      >
        <Minus size={18} strokeWidth={2.5} />
      </button>
    </div>
  );
}

export default function MapContainer({
  occurrences, categories, selectedOccurrence, onSelectOccurrence,
  onAddOccurrence, isAddingMode, onCancelAdd,
  center, zoom, onCenterChange, onZoomChange,
}: MapContainerProps) {
  const getCategoryColor = (id: string) => categories.find(c => c.id === id)?.color || '#6b7280';

  return (
    <div className="relative w-full h-full">
      {/* Estilos globais para o LayersControl do Leaflet — sobrescreve o visual
          padrão quadrado/cinza por um controle moderno no canto superior esquerdo */}
      <style>{`
        .leaflet-control-layers {
          border: none !important;
          border-radius: 12px !important;
          box-shadow: 0 2px 12px rgba(0,0,0,0.15) !important;
          overflow: hidden !important;
          font-family: inherit !important;
          min-width: 44px !important;
        }
        .leaflet-control-layers-toggle {
          width: 44px !important;
          height: 44px !important;
          background-color: white !important;
          background-image: none !important;
          display: flex !important;
          align-items: center !important;
          justify-content: center !important;
          border-radius: 12px !important;
          border: 1px solid #e2e8f0 !important;
          cursor: pointer !important;
        }
        .leaflet-control-layers-toggle::after {
          content: '⊞';
          font-size: 20px;
          color: #475569;
          line-height: 1;
        }
        .leaflet-control-layers-expanded {
          padding: 10px 14px !important;
          background: white !important;
          border-radius: 12px !important;
          min-width: 170px !important;
        }
        .leaflet-control-layers-expanded .leaflet-control-layers-toggle {
          display: none !important;
        }
        .leaflet-control-layers-base label {
          display: flex !important;
          align-items: center !important;
          gap: 8px !important;
          padding: 6px 4px !important;
          font-size: 13px !important;
          font-weight: 500 !important;
          color: #334155 !important;
          cursor: pointer !important;
          border-radius: 8px !important;
          transition: background 0.15s !important;
        }
        .leaflet-control-layers-base label:hover {
          background: #f1f5f9 !important;
        }
        .leaflet-control-layers-base input[type="radio"] {
          accent-color: #10b981 !important;
          width: 15px !important;
          height: 15px !important;
        }
        .leaflet-control-layers-separator { display: none !important; }
        .leaflet-control-layers-list { margin: 0 !important; }
      `}</style>

      <LeafletMap
        center={[center.lat, center.lng]}
        zoom={zoom}
        style={{ height: '100%', width: '100%', cursor: isAddingMode ? 'crosshair' : undefined }}
        zoomControl={false}
      >
        {/* ── Controle de Camadas ──────────────────────────────────── */}
        <LayersControl position="topleft">

          {/* Camada 1 — Satélite Esri + rótulos de ruas sobrepostos */}
          <LayersControl.BaseLayer checked name="🛰 Satélite">
            <LayerGroup>
              <TileLayer
                url="https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
                attribution='&copy; Esri, Maxar, Earthstar Geographics'
                maxZoom={19}
              />
              <TileLayer
                url="https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Transportation/MapServer/tile/{z}/{y}/{x}"
                maxZoom={19}
              />
              <TileLayer
                url="https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}"
                maxZoom={19}
                opacity={0.9}
              />
            </LayerGroup>
          </LayersControl.BaseLayer>

          {/* Camada 2 — Ruas vetorial estilo Google Maps (Carto Light) */}
          <LayersControl.BaseLayer name="🗺 Ruas">
            <TileLayer
              url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
              subdomains="abcd"
              maxZoom={20}
            />
          </LayersControl.BaseLayer>

        </LayersControl>

        <ClickHandler isAddingMode={isAddingMode} onAddOccurrence={onAddOccurrence} />
        <FlyToOnExternalChange center={center} zoom={zoom} />
        <ViewportSync onCenterChange={onCenterChange} onZoomChange={onZoomChange} />
        <ZoomButtons />

        {occurrences.map((occ) => {
          const isSelected = selectedOccurrence?.id === occ.id;
          const markerColor = statusColors[occ.status].marker;
          const categoryColor = getCategoryColor(occ.category_id);
          return (
            <Marker
              key={occ.id}
              position={[occ.latitude, occ.longitude]}
              icon={createStatusIcon(markerColor, categoryColor, isSelected)}
              eventHandlers={{ click: () => onSelectOccurrence(isSelected ? null : occ) }}
            >
              <Popup>
                <div className="min-w-44">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: markerColor }} />
                    <span className="text-xs font-semibold" style={{ color: markerColor }}>
                      {statusLabels[occ.status]}
                    </span>
                  </div>
                  <p className="font-semibold text-slate-900 text-sm leading-snug">{occ.title}</p>
                  {occ.category && (
                    <span
                      className="inline-block mt-1.5 px-2 py-0.5 rounded text-xs font-medium text-white"
                      style={{ backgroundColor: categoryColor }}
                    >
                      {occ.category.name}
                    </span>
                  )}
                </div>
              </Popup>
            </Marker>
          );
        })}
      </LeafletMap>

      {/* Banner do modo adicionar */}
      {isAddingMode && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[1000] animate-bounceIn pointer-events-none">
          <div className="flex items-center gap-3 bg-emerald-600 text-white px-5 py-3 rounded-full shadow-xl pointer-events-auto">
            <Navigation size={16} />
            <span className="text-sm font-bold">Clique no mapa para marcar a localização</span>
            <button
              onClick={onCancelAdd}
              className="ml-1 px-3 py-1 bg-white/20 hover:bg-white/30 rounded-full text-xs font-medium transition-colors"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Legenda de status */}
      <div className="absolute bottom-6 left-4 z-[1000] bg-white/95 backdrop-blur-sm border border-slate-200 rounded-xl shadow-lg p-3">
        <p className="text-xs font-semibold text-slate-600 mb-2 flex items-center gap-1.5">
          <Layers size={12} className="text-slate-400" />
          Cor = status
        </p>
        <div className="space-y-1">
          {(Object.keys(statusLabels) as Array<keyof typeof statusLabels>).map((key) => (
            <div key={key} className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: statusColors[key].marker }} />
              <span className="text-xs text-slate-500">{statusLabels[key]}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

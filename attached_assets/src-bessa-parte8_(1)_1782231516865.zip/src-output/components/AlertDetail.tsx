import { useState } from 'react';
import { Occurrence, OccurrenceStatus } from '../types';
import {
  X,
  MapPin,
  Clock,
  User,
  Mail,
  Phone,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  XCircle,
  MessageCircle,
  Calendar,
  Shield,
  Lock,
  Unlock,
  AlertCircle,
  Home,
  Signpost,
  Maximize2,
} from 'lucide-react';
import { statusLabels, severityLabels, statusColors, RESPONSIBLE_ORGANS } from '../data/constants';
import { isAdminUnlocked, unlockAdmin, lockAdmin, getAdminName } from '../lib/adminSession';

interface AlertDetailProps {
  occurrence: Occurrence;
  onClose: () => void;
  onUpdateStatus: (occurrenceId: string, newStatus: OccurrenceStatus, adminNotes?: string, responsibleOrgan?: string) => Promise<void>;
}

const STATUS_OPTIONS: OccurrenceStatus[] = ['pending', 'in_progress', 'resolved', 'rejected'];

export default function AlertDetail({ occurrence, onClose, onUpdateStatus }: AlertDetailProps) {
  const [adminUnlocked, setAdminUnlocked] = useState(isAdminUnlocked());
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [showLogin, setShowLogin] = useState(false);

  const [pendingStatus, setPendingStatus] = useState<OccurrenceStatus>(occurrence.status);
  const [adminNotes, setAdminNotes] = useState(occurrence.admin_notes ?? '');
  const [responsibleOrgan, setResponsibleOrgan] = useState(occurrence.responsible_organ ?? '');
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Lightbox para foto expandida
  const [photoExpanded, setPhotoExpanded] = useState(false);

  const getElapsedLabel = () => {
    const start = new Date(occurrence.created_at).getTime();
    const end = occurrence.resolved_at ? new Date(occurrence.resolved_at).getTime() : Date.now();
    const diffMs = end - start;
    const minutes = Math.floor(diffMs / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    const statusVerb = occurrence.status === 'resolved' ? 'Resolvida em' : statusLabels[occurrence.status] + ' há';
    if (days >= 1) return `${statusVerb} ${days} dia${days !== 1 ? 's' : ''}`;
    if (hours >= 1) return `${statusVerb} ${hours} hora${hours !== 1 ? 's' : ''}`;
    return `${statusVerb} ${minutes} minuto${minutes !== 1 ? 's' : ''}`;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock size={16} />;
      case 'in_progress': return <Loader2 size={16} className="animate-spin" />;
      case 'resolved': return <CheckCircle2 size={16} />;
      case 'rejected': return <XCircle size={16} />;
      default: return null;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-700 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'medium': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'low': return 'bg-slate-100 text-slate-700 border-slate-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const formatDate = (dateStr: string) =>
    new Date(dateStr).toLocaleString('pt-BR', {
      day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit',
    });

  const handleLogin = () => {
    const result = unlockAdmin(passwordInput);
    if (result.success) {
      setAdminUnlocked(true);
      setShowLogin(false);
      setLoginError(null);
      setPasswordInput('');
    } else {
      setLoginError(result.message);
    }
  };

  const handleLogout = () => { lockAdmin(); setAdminUnlocked(false); };

  const hasChanges =
    pendingStatus !== occurrence.status ||
    adminNotes !== (occurrence.admin_notes ?? '') ||
    responsibleOrgan !== (occurrence.responsible_organ ?? '');

  const handleSaveStatus = async () => {
    setIsSaving(true);
    setSaveError(null);
    setSaveSuccess(false);
    try {
      await onUpdateStatus(occurrence.id, pendingStatus, adminNotes.trim() || undefined, responsibleOrgan || undefined);
      setSaveSuccess(true);
    } catch (err) {
      console.error('Erro ao atualizar status:', err);
      setSaveError('Não foi possível salvar a alteração. Tente novamente.');
    } finally {
      setIsSaving(false);
    }
  };

  const currentStatusColors = statusColors[occurrence.status];
  const hasOfficialResponse = !!(occurrence.admin_notes || occurrence.responsible_organ);
  const organLabel = RESPONSIBLE_ORGANS.find(o => o.value === occurrence.responsible_organ)?.label ?? occurrence.responsible_organ;

  return (
    <>
      {/* Lightbox de foto expandida */}
      {photoExpanded && occurrence.image_url && (
        <div
          className="fixed inset-0 z-[200] bg-black/85 flex items-center justify-center p-4 animate-fadeIn"
          onClick={() => setPhotoExpanded(false)}
        >
          <button
            className="absolute top-4 right-4 w-10 h-10 bg-white/20 hover:bg-white/40 rounded-full flex items-center justify-center text-white transition-colors"
            onClick={() => setPhotoExpanded(false)}
          >
            <X size={20} />
          </button>
          <img
            src={occurrence.image_url}
            alt={occurrence.title}
            className="max-w-full max-h-[90vh] rounded-xl shadow-2xl object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}

      <div className="fixed inset-y-0 right-0 w-[480px] bg-white shadow-2xl z-50 flex flex-col animate-slideInRight">
        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-white">
          <div className="flex items-start justify-between">
            <div className="flex-1 pr-4">
              <div className="flex items-center gap-2 mb-2">
                <span
                  className="px-2.5 py-1 rounded-lg text-xs font-semibold border flex items-center gap-1.5"
                  style={{
                    backgroundColor: occurrence.category?.color + '15',
                    borderColor: occurrence.category?.color,
                    color: occurrence.category?.color,
                  }}
                >
                  <MapPin size={12} />
                  {occurrence.category?.name}
                </span>
                <span className={`px-2.5 py-1 rounded-lg text-xs font-semibold border flex items-center gap-1.5 ${getSeverityColor(occurrence.severity)}`}>
                  <AlertTriangle size={12} />
                  {severityLabels[occurrence.severity]}
                </span>
              </div>
              <h2 className="text-xl font-bold text-slate-900 leading-tight">{occurrence.title}</h2>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-400 hover:text-slate-600">
              <X size={22} />
            </button>
          </div>
          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <span className={`px-3 py-1.5 rounded-full text-sm font-medium border flex items-center gap-2 ${currentStatusColors.bg} ${currentStatusColors.text} ${currentStatusColors.border}`}>
              {getStatusIcon(occurrence.status)}
              {statusLabels[occurrence.status]}
            </span>
            <span className="text-sm text-slate-500 flex items-center gap-1.5">
              <Calendar size={14} />
              {formatDate(occurrence.created_at)}
            </span>
            <span className="ml-auto text-xs font-medium px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 border border-slate-200 flex items-center gap-1">
              <Clock size={11} />
              {getElapsedLabel()}
            </span>
          </div>
        </div>

        {/* Scrollable content */}
        <div className="flex-1 overflow-y-auto">

          {/* ── Foto (miniatura expansível) ──────────────────────────── */}
          {occurrence.image_url && (
            <div
              className="relative mx-5 mt-5 rounded-xl overflow-hidden border border-slate-200 shadow-sm cursor-pointer group"
              onClick={() => setPhotoExpanded(true)}
              title="Clique para ampliar"
            >
              <img
                src={occurrence.image_url}
                alt={occurrence.title}
                className="w-full h-44 object-cover group-hover:scale-[1.02] transition-transform duration-200"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
              <div className="absolute bottom-2 right-2 w-8 h-8 bg-black/50 group-hover:bg-black/70 rounded-lg flex items-center justify-center text-white transition-colors">
                <Maximize2 size={14} />
              </div>
              <p className="absolute bottom-2 left-3 text-white text-xs font-medium drop-shadow">
                Toque para ampliar
              </p>
            </div>
          )}

          {/* ── Descrição + Resposta Oficial (bloco unificado) ─────────── */}
          <div className="p-5 border-b border-slate-100">
            {/* Descrição do cidadão */}
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center">
                <MessageCircle size={16} className="text-slate-500" />
              </div>
              <h3 className="font-semibold text-slate-900">Descrição</h3>
            </div>
            <p className="text-slate-600 text-sm leading-relaxed">{occurrence.description}</p>

            {/* Resposta Oficial — logo abaixo da descrição, sem seção separada */}
            {hasOfficialResponse && (
              <div className="mt-4 rounded-xl border border-blue-200 bg-blue-50/60 overflow-hidden">
                <div className="flex items-center gap-2 px-4 pt-3 pb-2 border-b border-blue-100">
                  <div className="w-6 h-6 rounded-md bg-blue-100 flex items-center justify-center">
                    <Shield size={13} className="text-blue-600" />
                  </div>
                  <h4 className="text-sm font-semibold text-blue-900">Resposta oficial da Prefeitura</h4>
                  {occurrence.responsible_organ && (
                    <span className="ml-auto text-xs font-bold text-blue-700 uppercase tracking-wide bg-blue-100 px-2 py-0.5 rounded-full border border-blue-200">
                      {occurrence.responsible_organ}
                    </span>
                  )}
                </div>
                <div className="px-4 py-3 space-y-1.5">
                  {occurrence.responsible_organ && (
                    <p className="text-xs text-blue-600">{organLabel}</p>
                  )}
                  {occurrence.admin_notes && (
                    <p className="text-slate-700 text-sm leading-relaxed">{occurrence.admin_notes}</p>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* ── Localização ──────────────────────────────────────────── */}
          <div className="p-5 border-b border-slate-100">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                <MapPin size={16} className="text-emerald-600" />
              </div>
              <h3 className="font-semibold text-slate-900">Localização</h3>
            </div>
            <div className="space-y-2.5">
              <p className="text-slate-700 text-sm font-medium flex items-start gap-2">
                <Home size={14} className="text-slate-400 mt-0.5 flex-shrink-0" />
                {occurrence.street_address || <span className="text-slate-400 font-normal italic">Rua e número não informados</span>}
              </p>
              <p className="text-slate-700 text-sm flex items-start gap-2">
                <Signpost size={14} className="text-slate-400 mt-0.5 flex-shrink-0" />
                {occurrence.reference_point || <span className="text-slate-400 italic">Ponto de referência não informado</span>}
              </p>
              {occurrence.address && (
                <p className="text-slate-600 text-sm flex items-start gap-2">
                  <MapPin size={14} className="text-slate-400 mt-0.5 flex-shrink-0" />
                  {occurrence.address}
                </p>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-3 font-mono">
              {occurrence.latitude.toFixed(6)}, {occurrence.longitude.toFixed(6)}
            </p>
          </div>

          {/* ── Reportado por ────────────────────────────────────────── */}
          <div className="p-5 border-b border-slate-100">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center">
                <User size={16} className="text-blue-600" />
              </div>
              <h3 className="font-semibold text-slate-900">Reportado por</h3>
            </div>
            <div className="space-y-2">
              <p className="text-slate-700 text-sm font-medium flex items-center gap-2">
                <User size={14} className="text-slate-400" />
                {occurrence.user_name}
              </p>
              {occurrence.user_email && (
                <p className="text-slate-600 text-sm flex items-center gap-2">
                  <Mail size={14} className="text-slate-400" />
                  {occurrence.user_email}
                </p>
              )}
              {occurrence.user_phone && (
                <p className="text-slate-600 text-sm flex items-center gap-2">
                  <Phone size={14} className="text-slate-400" />
                  {occurrence.user_phone}
                </p>
              )}
            </div>
          </div>

          {/* ── Resolução ────────────────────────────────────────────── */}
          {(occurrence.resolved_at || occurrence.resolved_by) && (
            <div className="p-5 border-b border-slate-100 bg-emerald-50/50">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
                  <CheckCircle2 size={16} className="text-emerald-600" />
                </div>
                <h3 className="font-semibold text-slate-900">Resolução</h3>
              </div>
              <div className="space-y-2 text-sm">
                {occurrence.resolved_by && (
                  <p className="text-slate-600 flex items-center gap-2">
                    <Shield size={14} className="text-slate-400" />
                    Resolvido por: <span className="font-medium">{occurrence.resolved_by}</span>
                  </p>
                )}
                {occurrence.resolved_at && (
                  <p className="text-slate-600 flex items-center gap-2">
                    <Clock size={14} className="text-slate-400" />
                    Em: {formatDate(occurrence.resolved_at)}
                  </p>
                )}
              </div>
            </div>
          )}

          {/* ── Painel de gestão da prefeitura ───────────────────────── */}
          <div className="p-5">
            {!adminUnlocked ? (
              <div className="border border-dashed border-slate-300 rounded-xl p-4">
                {!showLogin ? (
                  <button
                    onClick={() => setShowLogin(true)}
                    className="w-full flex items-center justify-center gap-2 text-sm font-medium text-slate-500 hover:text-slate-700 py-1"
                  >
                    <Lock size={14} />
                    Sou da prefeitura — gerenciar status
                  </button>
                ) : (
                  <div className="space-y-3">
                    <p className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                      <Lock size={14} className="text-slate-400" />
                      Acesso da equipe da prefeitura
                    </p>
                    <input
                      type="password"
                      placeholder="Código de acesso (ex: BESSA2026)"
                      value={passwordInput}
                      onChange={(e) => { setPasswordInput(e.target.value); setLoginError(null); }}
                      onKeyDown={(e) => { if (e.key === 'Enter') handleLogin(); }}
                      autoFocus
                      className="w-full px-3 py-2 border border-slate-200 bg-slate-50 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                    {loginError && <p className="text-xs text-red-500">{loginError}</p>}
                    <div className="flex gap-2">
                      <button
                        onClick={() => { setShowLogin(false); setPasswordInput(''); setLoginError(null); }}
                        className="flex-1 px-3 py-2 text-xs font-medium text-slate-500 hover:bg-slate-100 rounded-lg transition-colors"
                      >
                        Cancelar
                      </button>
                      <button
                        onClick={handleLogin}
                        className="flex-1 px-3 py-2 bg-slate-800 hover:bg-slate-900 text-white text-xs font-medium rounded-lg transition-colors"
                      >
                        Entrar
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="border border-emerald-200 bg-emerald-50/40 rounded-xl p-4 space-y-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold text-emerald-800 flex items-center gap-2">
                    <Unlock size={14} />
                    Painel de gestão — {getAdminName()}
                  </p>
                  <button onClick={handleLogout} className="text-xs text-slate-500 hover:text-slate-700 underline">Sair</button>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-2 uppercase tracking-wide">Status da ocorrência</label>
                  <div className="grid grid-cols-2 gap-2">
                    {STATUS_OPTIONS.map((status) => {
                      const colors = statusColors[status];
                      const isActive = pendingStatus === status;
                      return (
                        <button
                          key={status}
                          onClick={() => { setPendingStatus(status); setSaveSuccess(false); }}
                          className={`px-3 py-2 rounded-lg text-sm font-medium border flex items-center gap-2 justify-center transition-all ${
                            isActive
                              ? `${colors.bg} ${colors.text} ${colors.border} ring-2 ring-offset-1`
                              : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'
                          }`}
                          style={isActive ? { boxShadow: `0 0 0 1px ${colors.marker}` } : undefined}
                        >
                          {getStatusIcon(status)}
                          {statusLabels[status]}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-2 uppercase tracking-wide">Órgão responsável</label>
                  <select
                    value={responsibleOrgan}
                    onChange={(e) => { setResponsibleOrgan(e.target.value); setSaveSuccess(false); }}
                    className="w-full px-3 py-2 border border-slate-200 bg-white rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="">— Não atribuído —</option>
                    {RESPONSIBLE_ORGANS.map((organ) => (
                      <option key={organ.value} value={organ.value}>{organ.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-2 uppercase tracking-wide">Nota administrativa (opcional)</label>
                  <textarea
                    value={adminNotes}
                    onChange={(e) => { setAdminNotes(e.target.value); setSaveSuccess(false); }}
                    rows={3}
                    placeholder="Ex: Equipe da Secretaria de Obras já notificada."
                    className="w-full px-3 py-2 border border-slate-200 bg-white rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                  />
                </div>

                {saveError && (
                  <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
                    <AlertCircle size={14} className="text-red-500 flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-red-700">{saveError}</p>
                  </div>
                )}
                {saveSuccess && !hasChanges && (
                  <div className="p-2.5 bg-emerald-100 border border-emerald-300 rounded-lg flex items-center gap-2">
                    <CheckCircle2 size={14} className="text-emerald-600 flex-shrink-0" />
                    <p className="text-xs text-emerald-800 font-medium">Status atualizado com sucesso.</p>
                  </div>
                )}

                <button
                  onClick={handleSaveStatus}
                  disabled={!hasChanges || isSaving}
                  className="w-full px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300 disabled:cursor-not-allowed text-white rounded-lg font-medium text-sm transition-colors flex items-center justify-center gap-2"
                >
                  {isSaving ? (
                    <>
                      <Loader2 size={16} className="animate-spin" />
                      Salvando...
                    </>
                  ) : (
                    'Salvar alteração'
                  )}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

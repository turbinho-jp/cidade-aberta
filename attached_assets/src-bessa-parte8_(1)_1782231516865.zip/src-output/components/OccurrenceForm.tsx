import { useState, useEffect, useRef } from 'react';
import { Category, Severity, MapCoordinates } from '../types';
import {
  X,
  MapPin,
  AlertTriangle,
  User,
  Mail,
  Phone,
  Image,
  Send,
  ChevronDown,
  Check,
  Loader2,
  AlertCircle,
  Home,
  Signpost,
  Sparkles,
  Camera,
  XCircle,
} from 'lucide-react';
import { severityLabels } from '../data/constants';
import { reverseGeocode, forwardGeocode } from '../services/geocoding';

interface OccurrenceFormProps {
  coordinates: MapCoordinates;
  categories: Category[];
  onClose: () => void;
  onSubmit: (data: OccurrenceFormData) => Promise<void>;
  onCoordinatesChange?: (coords: MapCoordinates) => void;
}

export interface OccurrenceFormData {
  title: string;
  description: string;
  category_id: string;
  latitude: number;
  longitude: number;
  street_address: string;
  reference_point: string;
  severity: Severity;
  user_name: string;
  user_email: string;
  user_phone: string;
  image_url: string;
}

export default function OccurrenceForm({
  coordinates,
  categories,
  onClose,
  onSubmit,
  onCoordinatesChange,
}: OccurrenceFormProps) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category_id: '',
    street_address: '',
    reference_point: '',
    severity: 'medium' as Severity,
    user_name: '',
    user_email: '',
    user_phone: '',
    image_url: '',
  });
  const [showCategoryDropdown, setShowCategoryDropdown] = useState(false);
  const [showSeverityDropdown, setShowSeverityDropdown] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);

  const [isGeocoding, setIsGeocoding] = useState(true);
  const [geocodeFilled, setGeocodeFilled] = useState(false);
  const [isForwardGeocoding, setIsForwardGeocoding] = useState(false);
  const [forwardGeocodeFailed, setForwardGeocodeFailed] = useState(false);
  const userEditedStreetAddress = useRef(false);
  const forwardGeocodeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Estado do upload de foto
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isConvertingImage, setIsConvertingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let cancelled = false;
    setIsGeocoding(true);

    reverseGeocode(coordinates.lat, coordinates.lng).then((result) => {
      if (cancelled) return;
      setIsGeocoding(false);
      if (result && !userEditedStreetAddress.current) {
        setFormData(prev => ({ ...prev, street_address: result.formattedAddress }));
        setGeocodeFilled(true);
      }
    });

    return () => { cancelled = true; };
  }, [coordinates.lat, coordinates.lng]);

  const selectedCategory = categories.find(c => c.id === formData.category_id);

  const handleStreetAddressChange = (value: string) => {
    userEditedStreetAddress.current = true;
    setFormData(prev => ({ ...prev, street_address: value }));
    setForwardGeocodeFailed(false);

    if (forwardGeocodeTimer.current) clearTimeout(forwardGeocodeTimer.current);
    if (!onCoordinatesChange || value.trim().length < 5) return;

    forwardGeocodeTimer.current = setTimeout(async () => {
      setIsForwardGeocoding(true);
      const result = await forwardGeocode(value);
      setIsForwardGeocoding(false);
      if (result) {
        setForwardGeocodeFailed(false);
        onCoordinatesChange({ lat: result.lat, lng: result.lng });
      } else {
        setForwardGeocodeFailed(true);
      }
    }, 1000);
  };

  // Converte o arquivo selecionado para Base64 e salva em formData.image_url
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Valida tamanho (máx 5 MB)
    if (file.size > 5 * 1024 * 1024) {
      setErrors(prev => ({ ...prev, image: 'A imagem deve ter no máximo 5 MB.' }));
      return;
    }

    setIsConvertingImage(true);
    setErrors(prev => { const { image: _, ...rest } = prev; return rest; });

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setImagePreview(base64);
      setFormData(prev => ({ ...prev, image_url: base64 }));
      setIsConvertingImage(false);
    };
    reader.onerror = () => {
      setErrors(prev => ({ ...prev, image: 'Erro ao processar a imagem. Tente novamente.' }));
      setIsConvertingImage(false);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    setImagePreview(null);
    setFormData(prev => ({ ...prev, image_url: '' }));
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.title.trim()) newErrors.title = 'Título é obrigatório';
    if (!formData.description.trim()) newErrors.description = 'Descrição é obrigatória';
    if (!formData.category_id) newErrors.category_id = 'Selecione uma categoria';
    if (!formData.street_address.trim()) newErrors.street_address = 'Rua e número são obrigatórios';
    if (!formData.reference_point.trim()) newErrors.reference_point = 'Ponto de referência é obrigatório';
    if (!formData.user_name.trim()) newErrors.user_name = 'Seu nome é obrigatório';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validate()) return;
    setSubmitError(null);
    setIsSubmitting(true);
    try {
      await onSubmit({
        ...formData,
        latitude: coordinates.lat,
        longitude: coordinates.lng,
      });
    } catch (err) {
      console.error('Erro ao enviar ocorrência:', err);
      setSubmitError('Não foi possível enviar sua ocorrência. Verifique sua conexão e tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const getSeverityColor = (severity: Severity) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-700 border-red-300';
      case 'high': return 'bg-orange-100 text-orange-700 border-orange-300';
      case 'medium': return 'bg-amber-100 text-amber-700 border-amber-300';
      case 'low': return 'bg-slate-100 text-slate-700 border-slate-300';
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 w-[480px] bg-white shadow-2xl z-50 flex flex-col animate-slideInRight">
      {/* Header */}
      <div className="p-5 border-b border-slate-200 bg-gradient-to-r from-emerald-500 to-teal-500">
        <div className="flex items-start justify-between">
          <div className="flex-1 pr-4">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
                <MapPin size={18} className="text-white" />
              </div>
              <span className="text-emerald-100 text-sm font-medium">Nova Ocorrência</span>
            </div>
            <h2 className="text-xl font-bold text-white leading-tight">Reporte um problema</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/20 rounded-lg transition-colors text-white">
            <X size={22} />
          </button>
        </div>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto p-5 space-y-6">
        {/* Coordinates */}
        <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 flex items-center justify-center">
              <MapPin size={20} className="text-emerald-600" />
            </div>
            <div>
              <p className="text-sm font-medium text-emerald-800">Localização selecionada</p>
              <p className="text-xs text-emerald-600 font-mono">
                {coordinates.lat.toFixed(6)}, {coordinates.lng.toFixed(6)}
              </p>
            </div>
          </div>
        </div>

        {/* Street address */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
            Rua e número <span className="text-red-500">*</span>
            {isGeocoding && (
              <span className="inline-flex items-center gap-1 text-xs font-normal text-emerald-600">
                <Loader2 size={12} className="animate-spin" />
                buscando endereço...
              </span>
            )}
            {isForwardGeocoding && (
              <span className="inline-flex items-center gap-1 text-xs font-normal text-blue-600">
                <Loader2 size={12} className="animate-spin" />
                localizando no mapa...
              </span>
            )}
            {!isGeocoding && !isForwardGeocoding && geocodeFilled && !userEditedStreetAddress.current && (
              <span className="inline-flex items-center gap-1 text-xs font-normal text-emerald-600">
                <Sparkles size={12} />
                preenchido automaticamente
              </span>
            )}
            {!isForwardGeocoding && forwardGeocodeFailed && (
              <span className="inline-flex items-center gap-1 text-xs font-normal text-amber-600">
                <AlertCircle size={12} />
                endereço não encontrado
              </span>
            )}
          </label>
          <div className="relative">
            <Home size={18} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Ex: Av. Gov. Flávio Ribeiro Coutinho, 120"
              value={formData.street_address}
              onChange={(e) => handleStreetAddressChange(e.target.value)}
              className={`w-full pl-12 pr-4 py-3 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all ${
                errors.street_address ? 'border-red-300 bg-red-50' : 'border-slate-200 bg-slate-50'
              }`}
            />
          </div>
          {errors.street_address && <p className="text-xs text-red-500 mt-1">{errors.street_address}</p>}
          <p className="text-xs text-slate-400 mt-1">
            {forwardGeocodeFailed
              ? 'Não conseguimos localizar esse endereço no mapa — o pino permanece onde você clicou.'
              : geocodeFilled && !userEditedStreetAddress.current
              ? 'Endereço estimado a partir do ponto marcado no mapa — confira e corrija se precisar.'
              : 'Digite o endereço completo para mover o pino no mapa, ou clique no mapa para preencher automaticamente.'}
          </p>
        </div>

        {/* Reference point */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Ponto de referência <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <Signpost size={18} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Ex: Próximo ao Manaíra Shopping"
              value={formData.reference_point}
              onChange={(e) => setFormData({ ...formData, reference_point: e.target.value })}
              className={`w-full pl-12 pr-4 py-3 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all ${
                errors.reference_point ? 'border-red-300 bg-red-50' : 'border-slate-200 bg-slate-50'
              }`}
            />
          </div>
          {errors.reference_point && <p className="text-xs text-red-500 mt-1">{errors.reference_point}</p>}
        </div>

        {/* Title */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Título da ocorrência <span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            placeholder="Ex: Buraco na rua principal"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className={`w-full px-4 py-3 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all ${
              errors.title ? 'border-red-300 bg-red-50' : 'border-slate-200 bg-slate-50'
            }`}
          />
          {errors.title && <p className="text-xs text-red-500 mt-1">{errors.title}</p>}
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Descrição <span className="text-red-500">*</span>
          </label>
          <textarea
            placeholder="Descreva o problema em detalhes..."
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            rows={4}
            className={`w-full px-4 py-3 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none ${
              errors.description ? 'border-red-300 bg-red-50' : 'border-slate-200 bg-slate-50'
            }`}
          />
          {errors.description && <p className="text-xs text-red-500 mt-1">{errors.description}</p>}
        </div>

        {/* Category dropdown */}
        <div className="relative">
          <label className="block text-sm font-semibold text-slate-700 mb-2">
            Categoria <span className="text-red-500">*</span>
          </label>
          <button
            onClick={() => setShowCategoryDropdown(!showCategoryDropdown)}
            className={`w-full px-4 py-3 border rounded-xl text-sm flex items-center justify-between transition-all ${
              errors.category_id ? 'border-red-300 bg-red-50' : 'border-slate-200 bg-slate-50'
            }`}
          >
            <div className="flex items-center gap-3">
              {selectedCategory ? (
                <>
                  <div className="w-6 h-6 rounded flex items-center justify-center" style={{ backgroundColor: selectedCategory.color }}>
                    <MapPin size={14} className="text-white" />
                  </div>
                  <span className="text-slate-700">{selectedCategory.name}</span>
                </>
              ) : (
                <span className="text-slate-400">Selecione uma categoria</span>
              )}
            </div>
            <ChevronDown size={18} className={`text-slate-400 transition-transform ${showCategoryDropdown ? 'rotate-180' : ''}`} />
          </button>
          {showCategoryDropdown && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-xl shadow-xl z-10 overflow-hidden animate-fadeIn">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => { setFormData({ ...formData, category_id: cat.id }); setShowCategoryDropdown(false); }}
                  className={`w-full px-4 py-3 flex items-center gap-3 hover:bg-slate-50 transition-colors ${formData.category_id === cat.id ? 'bg-slate-50' : ''}`}
                >
                  <div className="w-6 h-6 rounded flex items-center justify-center" style={{ backgroundColor: cat.color }}>
                    <MapPin size={14} className="text-white" />
                  </div>
                  <span className="text-slate-700 text-sm">{cat.name}</span>
                  {formData.category_id === cat.id && <Check size={16} className="text-emerald-600 ml-auto" />}
                </button>
              ))}
            </div>
          )}
          {errors.category_id && <p className="text-xs text-red-500 mt-1">{errors.category_id}</p>}
        </div>

        {/* Severity dropdown */}
        <div className="relative">
          <label className="block text-sm font-semibold text-slate-700 mb-2">Nível de severidade</label>
          <button
            onClick={() => setShowSeverityDropdown(!showSeverityDropdown)}
            className="w-full px-4 py-3 border rounded-xl text-sm flex items-center justify-between transition-all border-slate-200 bg-slate-50"
          >
            <div className="flex items-center gap-3">
              <div className={`w-6 h-6 rounded flex items-center justify-center ${getSeverityColor(formData.severity)}`}>
                <AlertTriangle size={14} />
              </div>
              <span className="text-slate-700">{severityLabels[formData.severity]}</span>
            </div>
            <ChevronDown size={18} className={`text-slate-400 transition-transform ${showSeverityDropdown ? 'rotate-180' : ''}`} />
          </button>
          {showSeverityDropdown && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-xl shadow-xl z-10 overflow-hidden animate-fadeIn">
              {(['low', 'medium', 'high', 'critical'] as Severity[]).map((sev) => (
                <button
                  key={sev}
                  onClick={() => { setFormData({ ...formData, severity: sev }); setShowSeverityDropdown(false); }}
                  className={`w-full px-4 py-3 flex items-center gap-3 hover:bg-slate-50 transition-colors ${formData.severity === sev ? 'bg-slate-50' : ''}`}
                >
                  <div className={`w-6 h-6 rounded flex items-center justify-center ${getSeverityColor(sev)}`}>
                    <AlertTriangle size={14} />
                  </div>
                  <span className="text-slate-700 text-sm">{severityLabels[sev]}</span>
                  {formData.severity === sev && <Check size={16} className="text-emerald-600 ml-auto" />}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ── Upload de Foto ───────────────────────────────────────────── */}
        <div>
          <label className="block text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
            <Camera size={16} className="text-slate-400" />
            Foto do problema (opcional)
          </label>

          {/* Área de upload — oculta quando já há preview */}
          {!imagePreview && (
            <label
              htmlFor="photo-upload"
              className="flex flex-col items-center justify-center gap-2 w-full h-32 border-2 border-dashed border-slate-300 rounded-xl bg-slate-50 hover:bg-emerald-50 hover:border-emerald-400 transition-all cursor-pointer group"
            >
              {isConvertingImage ? (
                <>
                  <Loader2 size={24} className="text-emerald-500 animate-spin" />
                  <p className="text-xs text-slate-500">Processando imagem...</p>
                </>
              ) : (
                <>
                  <div className="w-10 h-10 rounded-full bg-white border border-slate-200 flex items-center justify-center group-hover:border-emerald-300 transition-colors shadow-sm">
                    <Image size={20} className="text-slate-400 group-hover:text-emerald-500 transition-colors" />
                  </div>
                  <p className="text-sm font-medium text-slate-600 group-hover:text-emerald-700">Clique para anexar uma foto</p>
                  <p className="text-xs text-slate-400">Ou use a câmera do celular · PNG, JPG, WEBP · máx. 5 MB</p>
                </>
              )}
              <input
                id="photo-upload"
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                className="hidden"
                onChange={handleFileChange}
              />
            </label>
          )}

          {/* Preview da imagem selecionada */}
          {imagePreview && (
            <div className="relative rounded-xl overflow-hidden border border-slate-200 shadow-sm">
              <img
                src={imagePreview}
                alt="Preview da foto"
                className="w-full h-48 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
              <button
                type="button"
                onClick={handleRemoveImage}
                className="absolute top-2 right-2 w-8 h-8 bg-black/60 hover:bg-red-600 rounded-full flex items-center justify-center text-white transition-colors"
                title="Remover foto"
              >
                <XCircle size={16} />
              </button>
              <p className="absolute bottom-2 left-3 text-white text-xs font-medium drop-shadow">
                Foto anexada ✓
              </p>
            </div>
          )}

          {errors.image && <p className="text-xs text-red-500 mt-1">{errors.image}</p>}
        </div>

        {/* Divider — Contato */}
        <div className="border-t border-slate-200 pt-6">
          <p className="text-sm font-semibold text-slate-700 mb-4">Informações de contato</p>

          <div className="mb-4">
            <label className="block text-sm text-slate-600 mb-1.5">Seu nome <span className="text-red-500">*</span></label>
            <div className="relative">
              <User size={18} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Nome completo"
                value={formData.user_name}
                onChange={(e) => setFormData({ ...formData, user_name: e.target.value })}
                className={`w-full pl-12 pr-4 py-3 border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 ${
                  errors.user_name ? 'border-red-300 bg-red-50' : 'border-slate-200 bg-slate-50'
                }`}
              />
            </div>
            {errors.user_name && <p className="text-xs text-red-500 mt-1">{errors.user_name}</p>}
          </div>

          <div className="mb-4">
            <label className="block text-sm text-slate-600 mb-1.5">Email (opcional)</label>
            <div className="relative">
              <Mail size={18} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400" />
              <input
                type="email"
                placeholder="seu@email.com"
                value={formData.user_email}
                onChange={(e) => setFormData({ ...formData, user_email: e.target.value })}
                className="w-full pl-12 pr-4 py-3 border border-slate-200 bg-slate-50 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm text-slate-600 mb-1.5">Telefone (opcional)</label>
            <div className="relative">
              <Phone size={18} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400" />
              <input
                type="tel"
                placeholder="(00) 00000-0000"
                value={formData.user_phone}
                onChange={(e) => setFormData({ ...formData, user_phone: e.target.value })}
                className="w-full pl-12 pr-4 py-3 border border-slate-200 bg-slate-50 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="p-5 border-t border-slate-200 bg-slate-50">
        {submitError && (
          <div className="mb-3 p-3 bg-red-50 border border-red-200 rounded-xl flex items-start gap-2">
            <AlertCircle size={16} className="text-red-500 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-red-700">{submitError}</p>
          </div>
        )}
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-3 border border-slate-200 rounded-xl font-medium text-sm text-slate-600 hover:bg-slate-100 transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="flex-1 px-4 py-3 bg-emerald-500 hover:bg-emerald-600 disabled:bg-emerald-300 text-white rounded-xl font-medium text-sm transition-colors flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 size={18} className="animate-spin" />
                Enviando...
              </>
            ) : (
              <>
                <Send size={18} />
                Enviar ocorrência
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

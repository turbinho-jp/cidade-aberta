import { useState } from 'react';
import { Occurrence, Category, FilterState, OccurrenceStatus, Severity } from '../types';
import {
  MapPinned,
  Filter,
  ChevronDown,
  ChevronUp,
  X,
  Clock,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Loader2,
  Search,
  Trash2,
  Plus,
  Eye,
  EyeOff,
  FileText,
} from 'lucide-react';
import { statusLabels, severityLabels, statusColors, RESPONSIBLE_ORGANS } from '../data/constants';
import { getCategoryIcon } from '../data/categoryIcons';

interface SidebarProps {
  occurrences: Occurrence[];
  allOccurrences: Occurrence[];
  categories: Category[];
  filters: FilterState;
  onFiltersChange: (filters: FilterState) => void;
  selectedOccurrence: Occurrence | null;
  onSelectOccurrence: (occurrence: Occurrence | null) => void;
  onAddClick: () => void;
}

// ─── Utilitário: calcula tempo de resolução em dias ──────────────────────────
function resolutionDays(occ: Occurrence): string {
  if (!occ.resolved_at) return '—';
  const diff = new Date(occ.resolved_at).getTime() - new Date(occ.created_at).getTime();
  const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
  return `${days} dia${days !== 1 ? 's' : ''}`;
}

// ─── Módulo de Relatório Mensal ──────────────────────────────────────────────
function MonthlyReport({ allOccurrences, onClose }: { allOccurrences: Occurrence[]; onClose: () => void }) {
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  // Filtra apenas ocorrências do mês atual
  const monthly = allOccurrences.filter((o) => {
    const d = new Date(o.created_at);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  });

  const totalAbertos = monthly.length;
  const totalResolvidos = monthly.filter(o => o.status === 'resolved').length;

  // Média de dias para resolução (apenas ocorrências resolvidas)
  const resolvedWithTime = monthly.filter(o => o.status === 'resolved' && o.resolved_at);
  const avgDays = resolvedWithTime.length > 0
    ? (resolvedWithTime.reduce((acc, o) => {
        const diff = new Date(o.resolved_at!).getTime() - new Date(o.created_at).getTime();
        return acc + diff / (1000 * 60 * 60 * 24);
      }, 0) / resolvedWithTime.length).toFixed(1)
    : '—';

  const monthName = now.toLocaleString('pt-BR', { month: 'long', year: 'numeric' });
  const generatedAt = now.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

  const getOrganLabel = (value: string | null) => {
    if (!value) return '—';
    return RESPONSIBLE_ORGANS.find(o => o.value === value)?.value ?? value;
  };

  const getStatusLabel = (status: OccurrenceStatus) => statusLabels[status];

  return (
    <>
      {/* Estilos de impressão — @media print oculta o overlay e imprime só o doc */}
      <style>{`
        @media print {
          body > *:not(#monthly-report-overlay) { display: none !important; }
          #monthly-report-overlay { position: static !important; background: white !important; }
          .no-print { display: none !important; }
          .print-doc {
            font-size: 11px;
            color: black;
          }
          @page { margin: 18mm 14mm; size: A4 portrait; }
        }
      `}</style>

      <div
        id="monthly-report-overlay"
        className="fixed inset-0 z-[300] bg-black/60 flex items-start justify-center overflow-y-auto py-8 px-4"
      >
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl print-doc">

          {/* Barra de ações — oculta na impressão */}
          <div className="no-print flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-slate-50 rounded-t-2xl">
            <div className="flex items-center gap-2">
              <FileText size={18} className="text-slate-500" />
              <span className="font-semibold text-slate-700 text-sm">Relatório Mensal — {monthName}</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => window.print()}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium rounded-lg transition-colors flex items-center gap-2"
              >
                🖨 Imprimir / Salvar PDF
              </button>
              <button
                onClick={onClose}
                className="p-2 hover:bg-slate-200 rounded-lg transition-colors text-slate-500"
              >
                <X size={18} />
              </button>
            </div>
          </div>

          {/* Documento */}
          <div className="p-8">

            {/* Cabeçalho institucional */}
            <div className="text-center border-b-2 border-slate-800 pb-5 mb-6">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-widest mb-1">Documento Oficial</p>
              <h1 className="text-xl font-bold text-slate-900 leading-tight">
                Associação Comunitária São Luiz (ASCOMSL)
              </h1>
              <h2 className="text-base font-semibold text-slate-700 mt-0.5">
                Ouvidoria Coletiva do Bessa
              </h2>
              <p className="text-sm text-slate-500 mt-2">
                Relatório Mensal de Ocorrências — <span className="font-medium capitalize">{monthName}</span>
              </p>
              <p className="text-xs text-slate-400 mt-1">Gerado em {generatedAt}</p>
            </div>

            {/* Quadro de resumo estatístico */}
            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="border border-slate-200 rounded-xl p-4 text-center bg-slate-50">
                <p className="text-3xl font-bold text-slate-800">{totalAbertos}</p>
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mt-1">Casos Abertos no Mês</p>
              </div>
              <div className="border border-emerald-200 rounded-xl p-4 text-center bg-emerald-50">
                <p className="text-3xl font-bold text-emerald-700">{totalResolvidos}</p>
                <p className="text-xs font-semibold text-emerald-600 uppercase tracking-wide mt-1">Resolvidos</p>
                <p className="text-xs text-emerald-500 mt-0.5">
                  {totalAbertos > 0 ? `${Math.round((totalResolvidos / totalAbertos) * 100)}% do total` : '—'}
                </p>
              </div>
              <div className="border border-blue-200 rounded-xl p-4 text-center bg-blue-50">
                <p className="text-3xl font-bold text-blue-700">{avgDays}</p>
                <p className="text-xs font-semibold text-blue-600 uppercase tracking-wide mt-1">Média de Dias p/ Resolução</p>
                <p className="text-xs text-blue-500 mt-0.5">
                  {resolvedWithTime.length > 0 ? `${resolvedWithTime.length} caso(s) analisado(s)` : 'Sem dados'}
                </p>
              </div>
            </div>

            {/* Tabela de ocorrências */}
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wide mb-3 flex items-center gap-2">
              <span className="w-1 h-4 bg-emerald-500 rounded-full inline-block" />
              Listagem de Ocorrências do Mês
            </h3>

            {monthly.length === 0 ? (
              <div className="text-center py-12 text-slate-400 border border-dashed border-slate-200 rounded-xl">
                <FileText size={32} className="mx-auto mb-2 opacity-40" />
                <p className="text-sm">Nenhuma ocorrência registrada neste mês.</p>
              </div>
            ) : (
              <div className="overflow-x-auto rounded-xl border border-slate-200">
                <table className="w-full text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-800 text-white">
                      <th className="px-3 py-2.5 text-left font-semibold whitespace-nowrap">ID</th>
                      <th className="px-3 py-2.5 text-left font-semibold whitespace-nowrap">Data de Abertura</th>
                      <th className="px-3 py-2.5 text-left font-semibold">Endereço Completo</th>
                      <th className="px-3 py-2.5 text-left font-semibold">Categoria</th>
                      <th className="px-3 py-2.5 text-left font-semibold whitespace-nowrap">Órgão Responsável</th>
                      <th className="px-3 py-2.5 text-left font-semibold whitespace-nowrap">Tempo de Resolução</th>
                      <th className="px-3 py-2.5 text-left font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {monthly.map((occ, idx) => (
                      <tr
                        key={occ.id}
                        className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}
                      >
                        <td className="px-3 py-2.5 font-mono text-slate-500 whitespace-nowrap border-b border-slate-100">
                          #{occ.id.slice(0, 8).toUpperCase()}
                        </td>
                        <td className="px-3 py-2.5 whitespace-nowrap text-slate-600 border-b border-slate-100">
                          {new Date(occ.created_at).toLocaleDateString('pt-BR')}
                        </td>
                        <td className="px-3 py-2.5 text-slate-700 border-b border-slate-100 max-w-[180px]">
                          <p className="font-medium truncate" title={occ.street_address ?? ''}>
                            {occ.street_address || occ.address || '—'}
                          </p>
                          {occ.reference_point && (
                            <p className="text-slate-400 truncate text-xs" title={occ.reference_point}>
                              {occ.reference_point}
                            </p>
                          )}
                        </td>
                        <td className="px-3 py-2.5 text-slate-600 border-b border-slate-100 whitespace-nowrap">
                          {occ.category?.name ?? '—'}
                        </td>
                        <td className="px-3 py-2.5 font-semibold text-slate-700 border-b border-slate-100 whitespace-nowrap">
                          {getOrganLabel(occ.responsible_organ)}
                        </td>
                        <td className="px-3 py-2.5 text-slate-600 border-b border-slate-100 whitespace-nowrap">
                          {resolutionDays(occ)}
                        </td>
                        <td className="px-3 py-2.5 border-b border-slate-100 whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded-full text-xs font-semibold border ${statusColors[occ.status].bg} ${statusColors[occ.status].text} ${statusColors[occ.status].border}`}>
                            {getStatusLabel(occ.status)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Rodapé do documento */}
            <div className="mt-8 pt-4 border-t border-slate-200 flex items-center justify-between text-xs text-slate-400">
              <span>ASCOMSL — Ouvidoria Coletiva do Bessa · João Pessoa/PB</span>
              <span>Bessa em Mapa © {currentYear}</span>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

// ─── Sidebar principal ───────────────────────────────────────────────────────
export default function Sidebar({
  occurrences,
  allOccurrences,
  categories,
  filters,
  onFiltersChange,
  selectedOccurrence,
  onSelectOccurrence,
  onAddClick,
}: SidebarProps) {
  const [showFilters, setShowFilters] = useState(false);
  const [showReport, setShowReport] = useState(false);

  const filteredOccs = occurrences.filter((occ) => {
    if (filters.categories.length > 0 && !filters.categories.includes(occ.category_id)) return false;
    if (filters.statuses.length > 0 && !filters.statuses.includes(occ.status)) return false;
    if (filters.severities.length > 0 && !filters.severities.includes(occ.severity)) return false;
    if (filters.search && !occ.title.toLowerCase().includes(filters.search.toLowerCase())) return false;
    return true;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock size={12} />;
      case 'in_progress': return <Loader2 size={12} className="animate-spin" />;
      case 'resolved': return <CheckCircle2 size={12} />;
      case 'rejected': return <XCircle size={12} />;
      default: return null;
    }
  };

  const toggleFilter = (type: 'categories' | 'statuses' | 'severities', value: string) => {
    const current = filters[type] as string[];
    const updated = current.includes(value) ? current.filter(v => v !== value) : [...current, value];
    onFiltersChange({ ...filters, [type]: updated } as FilterState);
  };

  const clearFilters = () => {
    onFiltersChange({ categories: [], statuses: [], severities: [], dateRange: { start: null, end: null }, search: '', showResolved: false });
  };

  const hasActiveFilters = filters.categories.length > 0 || filters.statuses.length > 0 || filters.severities.length > 0 || filters.search.length > 0;

  return (
    <>
      {showReport && (
        <MonthlyReport allOccurrences={allOccurrences} onClose={() => setShowReport(false)} />
      )}

      <div className="w-96 h-full bg-white border-r border-slate-200 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-gradient-to-r from-emerald-600 to-teal-600">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center">
                <MapPinned className="text-white" size={20} />
              </div>
              <div>
                <h1 className="text-base font-bold text-white leading-tight">Bessa em Mapa</h1>
                <p className="text-xs text-emerald-100">Ouvidoria cidadã — Bessa, João Pessoa</p>
              </div>
            </div>
            <button
              onClick={onAddClick}
              className="px-3 py-2 bg-white hover:bg-emerald-50 text-emerald-700 rounded-lg font-medium text-sm transition-colors shadow-sm flex items-center gap-1.5"
            >
              <Plus size={14} />
              Reportar
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="p-4 border-b border-slate-200">
          <div className="relative">
            <Search size={18} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar ocorrência..."
              value={filters.search}
              onChange={(e) => onFiltersChange({ ...filters, search: e.target.value })}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-lg text-sm text-slate-700 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
            />
            {filters.search && (
              <button onClick={() => onFiltersChange({ ...filters, search: '' })} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-slate-600">
                <X size={16} />
              </button>
            )}
          </div>
        </div>

        {/* Filters + Botão Exportar */}
        <div className="px-4 py-3 border-b border-slate-200 space-y-3">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center justify-between w-full text-sm font-semibold text-slate-700 hover:text-slate-900"
          >
            <div className="flex items-center gap-2">
              <Filter size={16} />
              <span>Filtros</span>
              {hasActiveFilters && (
                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-xs border border-emerald-200">
                  {filters.categories.length + filters.statuses.length + filters.severities.length}
                </span>
              )}
            </div>
            {showFilters ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
          </button>

          {/* Botão Exportar Relatório Mensal */}
          <button
            onClick={() => setShowReport(true)}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-medium text-sm transition-colors shadow-sm"
          >
            <FileText size={15} />
            Exportar Relatório Mensal
          </button>

          {showFilters && (
            <div className="mt-1 space-y-4 animate-collapseIn">
              <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="flex items-center gap-2">
                  {filters.showResolved ? <Eye size={16} className="text-emerald-600" /> : <EyeOff size={16} className="text-slate-400" />}
                  <div>
                    <p className="text-sm font-medium text-slate-700">Mostrar resolvidas</p>
                    <p className="text-xs text-slate-400">Ocultas por padrão para não poluir o mapa</p>
                  </div>
                </div>
                <button
                  role="switch"
                  aria-checked={filters.showResolved}
                  onClick={() => onFiltersChange({ ...filters, showResolved: !filters.showResolved })}
                  className={`relative w-10 h-6 rounded-full transition-colors flex-shrink-0 ${filters.showResolved ? 'bg-emerald-500' : 'bg-slate-300'}`}
                >
                  <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${filters.showResolved ? 'translate-x-4' : 'translate-x-0'}`} />
                </button>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wide">Categorias</label>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {categories.map((cat) => {
                    const Icon = getCategoryIcon(cat.icon);
                    return (
                      <button
                        key={cat.id}
                        onClick={() => toggleFilter('categories', cat.id)}
                        className="px-2.5 py-1 rounded-full text-xs font-medium border transition-all flex items-center gap-1"
                        style={
                          filters.categories.includes(cat.id)
                            ? { backgroundColor: cat.color + '20', color: cat.color, borderColor: cat.color + '60' }
                            : { backgroundColor: '#f8fafc', color: '#64748b', borderColor: '#e2e8f0' }
                        }
                      >
                        <Icon size={13} />
                        {cat.name}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wide">Status</label>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {(['pending', 'in_progress', 'resolved', 'rejected'] as OccurrenceStatus[]).map((status) => {
                    const colors = statusColors[status];
                    const isResolvedButHidden = status === 'resolved' && !filters.showResolved;
                    return (
                      <button
                        key={status}
                        onClick={() => !isResolvedButHidden && toggleFilter('statuses', status)}
                        disabled={isResolvedButHidden}
                        title={isResolvedButHidden ? 'Ative "Mostrar resolvidas" acima para usar este filtro' : undefined}
                        className={`px-2.5 py-1 rounded-full text-xs font-medium border transition-all flex items-center gap-1 ${
                          isResolvedButHidden
                            ? 'bg-slate-50 border-slate-100 text-slate-300 cursor-not-allowed'
                            : filters.statuses.includes(status)
                            ? `${colors.bg} ${colors.text} ${colors.border}`
                            : 'bg-slate-50 border-slate-200 text-slate-500 hover:border-slate-300'
                        }`}
                      >
                        {getStatusIcon(status)}
                        {statusLabels[status]}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-slate-400 uppercase tracking-wide">Severidade</label>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {(['low', 'medium', 'high', 'critical'] as Severity[]).map((sev) => {
                    const colors: Record<string, string> = {
                      low: 'text-slate-600 bg-slate-100 border-slate-300',
                      medium: 'text-amber-700 bg-amber-50 border-amber-200',
                      high: 'text-orange-700 bg-orange-50 border-orange-200',
                      critical: 'text-red-700 bg-red-50 border-red-200',
                    };
                    return (
                      <button
                        key={sev}
                        onClick={() => toggleFilter('severities', sev)}
                        className={`px-2.5 py-1 rounded-full text-xs font-medium border transition-all ${
                          filters.severities.includes(sev) ? colors[sev] : 'bg-slate-50 border-slate-200 text-slate-500'
                        }`}
                      >
                        {severityLabels[sev]}
                      </button>
                    );
                  })}
                </div>
              </div>

              {hasActiveFilters && (
                <button onClick={clearFilters} className="w-full py-2 text-xs font-medium text-slate-500 hover:text-slate-700 flex items-center justify-center gap-1 transition-colors">
                  <Trash2 size={14} />
                  Limpar filtros
                </button>
              )}
            </div>
          )}
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto">
          <div className="px-4 py-3 bg-slate-50 border-b border-slate-200">
            <p className="text-xs font-medium text-slate-500">
              {filteredOccs.length} ocorrência{filteredOccs.length !== 1 ? 's' : ''} encontrada{filteredOccs.length !== 1 ? 's' : ''}
            </p>
          </div>

          {filteredOccs.length === 0 ? (
            <div className="p-8 text-center">
              <div className="w-16 h-16 mx-auto mb-4 bg-slate-50 rounded-full flex items-center justify-center border border-slate-200">
                <MapPinned size={24} className="text-slate-300" />
              </div>
              <p className="text-slate-500 font-medium">Nenhuma ocorrência encontrada</p>
              <p className="text-xs text-slate-400 mt-1">Ajuste os filtros ou reporte um novo problema</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              {filteredOccs.map((occ) => {
                const isSelected = selectedOccurrence?.id === occ.id;
                const category = categories.find(c => c.id === occ.category_id);
                const Icon = category ? getCategoryIcon(category.icon) : MapPinned;
                const colors = statusColors[occ.status];
                return (
                  <div
                    key={occ.id}
                    onClick={() => onSelectOccurrence(isSelected ? null : occ)}
                    className={`p-4 cursor-pointer transition-all ${
                      isSelected ? 'bg-emerald-50 border-l-4 border-emerald-500' : 'hover:bg-slate-50 border-l-4 border-transparent'
                    }`}
                  >
                    <div className="flex gap-3">
                      <div
                        className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 border"
                        style={{ backgroundColor: (category?.color || '#6b7280') + '15', borderColor: (category?.color || '#6b7280') + '40' }}
                      >
                        <Icon size={18} style={{ color: category?.color || '#6b7280' }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="font-semibold text-slate-800 text-sm truncate">{occ.title}</h3>
                          {occ.severity === 'critical' && <AlertTriangle size={12} className="text-red-500 flex-shrink-0 mt-0.5" />}
                        </div>
                        {(occ.street_address || occ.address) && (
                          <p className="text-xs text-slate-400 truncate mt-0.5">{occ.street_address || occ.address}</p>
                        )}
                        <div className="flex flex-wrap items-center gap-2 mt-2">
                          <span className={`px-2 py-0.5 rounded text-xs font-medium border flex items-center gap-1 ${colors.bg} ${colors.text} ${colors.border}`}>
                            {getStatusIcon(occ.status)}
                            {statusLabels[occ.status]}
                          </span>
                          <span className="text-xs text-slate-400">
                            {new Date(occ.created_at).toLocaleDateString('pt-BR')}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer stats */}
        <div className="p-4 bg-slate-50 border-t border-slate-200">
          <div className="grid grid-cols-4 gap-2 text-center">
            <div>
              <p className="text-lg font-bold text-red-500">{allOccurrences.filter(o => o.status === 'pending').length}</p>
              <p className="text-xs text-slate-400">Pendentes</p>
            </div>
            <div>
              <p className="text-lg font-bold text-amber-500">{allOccurrences.filter(o => o.status === 'in_progress').length}</p>
              <p className="text-xs text-slate-400">Andamento</p>
            </div>
            <div>
              <p className="text-lg font-bold text-emerald-500">{allOccurrences.filter(o => o.status === 'resolved').length}</p>
              <p className="text-xs text-slate-400">Resolvidos</p>
            </div>
            <div>
              <p className="text-lg font-bold text-slate-400">{allOccurrences.filter(o => o.status === 'rejected').length}</p>
              <p className="text-xs text-slate-400">Rejeitados</p>
            </div>
          </div>
          {!filters.showResolved && allOccurrences.some(o => o.status === 'resolved') && (
            <button
              onClick={() => onFiltersChange({ ...filters, showResolved: true })}
              className="w-full mt-3 py-2 text-xs font-medium text-emerald-600 hover:text-emerald-700 flex items-center justify-center gap-1.5 border border-dashed border-emerald-200 rounded-lg hover:bg-emerald-50 transition-colors"
            >
              <Eye size={13} />
              {allOccurrences.filter(o => o.status === 'resolved').length} resolvida(s) oculta(s) — mostrar
            </button>
          )}
        </div>
      </div>
    </>
  );
}

import { Occurrence } from '../types';
import {
  Clock,
  Loader2,
  CheckCircle2,
  XCircle,
  TrendingUp,
  MapPinned,
  AlertTriangle,
} from 'lucide-react';

interface StatusBarProps {
  occurrences: Occurrence[];
}

export default function StatusBar({ occurrences }: StatusBarProps) {
  const pending = occurrences.filter(o => o.status === 'pending').length;
  const inProgress = occurrences.filter(o => o.status === 'in_progress').length;
  const resolved = occurrences.filter(o => o.status === 'resolved').length;
  const rejected = occurrences.filter(o => o.status === 'rejected').length;
  const total = occurrences.length;
  const resolutionRate = total > 0 ? ((resolved / total) * 100).toFixed(0) : '0';

  const critical = occurrences.filter(o => o.severity === 'critical' && o.status !== 'resolved').length;

  const now = new Date();
  const lastWeek = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const recent = occurrences.filter(o => new Date(o.created_at) >= lastWeek).length;

  return (
    <div className="bg-white border-b border-slate-200 px-6 py-2.5">
      <div className="flex items-center justify-between flex-wrap gap-y-2">
        {/* Left stats */}
        <div className="flex items-center gap-5 flex-wrap">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-600 to-teal-600 flex items-center justify-center">
              <MapPinned size={16} className="text-white" />
            </div>
            <div>
              <p className="text-lg font-bold text-slate-800">{total}</p>
              <p className="text-xs text-slate-400">Ocorrências</p>
            </div>
          </div>

          <div className="w-px h-8 bg-slate-200" />

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5">
              <Clock size={14} className="text-red-500" />
              <span className="font-bold text-red-500">{pending}</span>
              <span className="text-xs text-slate-400">Pendentes</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Loader2 size={14} className="text-amber-500" />
              <span className="font-bold text-amber-500">{inProgress}</span>
              <span className="text-xs text-slate-400">Em andamento</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 size={14} className="text-emerald-500" />
              <span className="font-bold text-emerald-500">{resolved}</span>
              <span className="text-xs text-slate-400">Resolvidas</span>
            </div>
            <div className="flex items-center gap-1.5">
              <XCircle size={14} className="text-slate-400" />
              <span className="font-bold text-slate-400">{rejected}</span>
              <span className="text-xs text-slate-400">Rejeitadas</span>
            </div>
          </div>
        </div>

        {/* Center - critical alert */}
        {critical > 0 && (
          <div className="flex items-center gap-2 px-3 py-1.5 bg-red-50 border border-red-200 rounded-lg">
            <AlertTriangle size={14} className="text-red-500" />
            <span className="font-bold text-red-600 text-sm">{critical}</span>
            <span className="text-xs text-red-500">crítica{critical !== 1 ? 's' : ''} em aberto</span>
          </div>
        )}

        {/* Right stats */}
        <div className="flex items-center gap-5">
          <div className="flex items-center gap-2">
            <TrendingUp size={14} className="text-emerald-500" />
            <div className="flex items-baseline gap-1">
              <span className="font-bold text-emerald-600">{resolutionRate}%</span>
              <span className="text-xs text-slate-400">resolução</span>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="text-emerald-600 font-bold">{recent}</span>
            <span>últ. 7 dias</span>
          </div>
        </div>
      </div>
    </div>
  );
}
